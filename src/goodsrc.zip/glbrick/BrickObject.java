package glbrick;

public class BrickObject {

	public int findColor() {
		// TODO Auto-generated method stub
		return 0;
	}

}
