package glbrick;

import java.util.ArrayList;

import static org.lwjgl.opengl.GL11.*;
//import static org.lwjgl.opengl.GL12.*;
//import static org.lwjgl.opengl.GL13.*;
//import static org.lwjgl.opengl.GL20.*;

public class DrawnObject
{
	private boolean comment = false;
	public float[] color = { 1, 1, 1 }; // Default is white
	ArrayList<DrawnObject> children = new ArrayList<DrawnObject>(); // Non-parts will have no children.
	double[][] transformation = identityMatrix();
	public double[] location = { 0, 0, 0 }; // In Cartesian
	public ArrayList<double[]> vertices = new ArrayList<double[]>();

	//This is only called by the CommentSpec.toDrawnObject() method.
	public DrawnObject()
	{
		comment = true;
	}

	//Constructor for a general DrawnObject that requires all of the fields set. This one will not be called except internally (I think)
	//However, I don't want to make it private just yet.
	public DrawnObject(ArrayList<double[]> vertices, double[] location, double[][] transformation, float[] color, ArrayList<DrawnObject> children)
	{
		this.children = children;
		this.transformation = transformation;
		this.vertices = vertices;
		transformVertices();
		this.location = location;
		this.color = color;
	}

	public DrawnObject(ArrayList<DrawnObject> children)
	{
		this(new ArrayList<double[]>(), new double[] { 0, 0, 0 }, identityMatrix(), new float[] { 1, 1, 1 }, children);
	}

	// constructor for non-linetype 1 specs
	public DrawnObject(ArrayList<double[]> vertices, float[] color)
	{
		this(vertices, new double[] { 0, 0, 0 }, identityMatrix(), color, new ArrayList<DrawnObject>());
	}

	// constructor for testing purposes
	public DrawnObject(ArrayList<double[]> vertices, double[] location, float[] color)
	{
		this(vertices, location, identityMatrix(), color, new ArrayList<DrawnObject>());
	}

	// constructor for linetype 1's
	public DrawnObject(double[] location, double[][] transformation, float[] color, ArrayList<DrawnObject> children)
	{
		this(new ArrayList<double[]>(), location, transformation, color, children);
	}

	public void setTransformation(double[][] trans)
	{
		for (int i = 0; i < trans.length; i++)
		{
			for (int j = 0; j < trans[0].length; j++)
			{
				transformation[i][j] = trans[i][j];
			}
		}
		transformALL(transformation);

	}

	public void setLocation(double[] loc)
	{
		location[0] = loc[0];
		location[1] = loc[1];
		location[2] = loc[2];
		for (DrawnObject child : children)
		{
			child.setLocation(loc);
		}
	}

	public void transformALL(double[][] trans)
	{
		transformVertices(trans);

		for (DrawnObject d : children)
		{
			d.transformVertices(trans);
		}
	}

	public void move(double[] vector)
	{
		location[0] += vector[0];
		location[1] += vector[1];
		location[2] += vector[2];
	}

	public void moveALL(double[] vector)
	{
		move(vector);
		//for(int i = 0; i < children.size(); i++){
		//	children.get(i).moveALL(vector);
		//}
	}

	public static double[][] identityMatrix()
	{
		return new double[][] { { 1, 0, 0, 0 }, { 0, 1, 0, 0 }, { 0, 0, 1, 0 }, { 0, 0, 0, 1 } };

	}

	// Returns the location of the object in spherical coordinates,
	// [r,theta,phi]
	// These three are -------------------------------------------------------
	public double[] getSphericalCoordinates()
	{
		double[] rtp = new double[3];
		rtp[0] = Math.sqrt(location[0] * location[0] + location[1] * location[1] + location[2] * location[2]);
		rtp[1] = 0;// Math.acos(location[1]/rtp[0]);
		rtp[2] = Math.atan2(location[0], location[2]);

		return rtp;
	}

	public void setSphericalCoordiates(double[] rtp)
	{
		double r = rtp[0];
		double theta = rtp[1];
		double phi = rtp[2];

		location[2] = r * Math.cos(phi);
		location[0] = r * Math.sin(phi);

	}

	public void revolve(double theta, double phi)
	{

		double[] rtp = getSphericalCoordinates();
		rtp[1] += theta;
		rtp[2] += phi;
		setSphericalCoordiates(rtp);
	}

	// ---------------methods used to perform a rendering test (the spiral galaxy test).

	public void transformVertices()
	{
		transformVertices(transformation);
	}

	// This method will change later because of how rendering is currently handled. The transformations should not modify the set of vertices.
	public void transformVertices(double[][] transformation)
	{

		for (int i = 0; i < vertices.size(); i++)
		{
			double[] vertex = vertices.get(i);
			vertex = matrixMult(transformation, vertex);
			vertices.set(i, vertex);

		}

	}

	public double[] matrixMult(double[][] m, double[] v)
	{
		double[] newv = new double[v.length];
		newv[0] = v[0] * m[0][0] + v[1] * m[0][1] + v[2] * m[0][2];
		newv[1] = v[0] * m[1][0] + v[1] * m[1][1] + v[2] * m[1][2];
		newv[2] = v[0] * m[2][0] + v[1] * m[2][1] + v[2] * m[2][2];
		return newv;
	}

	public double[] copyArray(double[] vertex)
	{
		double[] newVertex = new double[vertex.length];
		for (int i = 0; i < vertex.length; i++)
		{
			newVertex[i] = vertex[i];
		}
		return newVertex;
	}

	public void draw()
	{
		if (comment)
			return;

		if (children.size() > 0)
		{
			for (DrawnObject child : children)
			{
				child.draw();
			}
		} else
		{
			glBegin(GL_LINE_LOOP);
			glColor3f(color[0], color[1], color[2]);
			for (double[] vertex : vertices)
			{
				glVertex3d(vertex[0] + location[0], vertex[1] + location[1], vertex[2] + location[2]);

			}
			glEnd();
		}

	}

	public String toString()
	{
		return "Location: " + location[0] + ", " + location[1] + ", " + location[2];
	}

	public boolean isComment()
	{
		return comment;
	}

}
