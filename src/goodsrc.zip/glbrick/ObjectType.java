package glbrick;
//This is unused currently; we will implement it if it becomes necessary. Right now a DrawnObject does not need to be told what linetype it is because it can infer this from its own data.
public enum ObjectType
{
	PART,LINE,TRIANGLE,QUAD,OPTIONALLINE;
	
}
